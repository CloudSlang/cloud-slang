def full_version(version):
	return 'build(' + str(version) + '):version(5)'
